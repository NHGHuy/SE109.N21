import React from "react";

Sale.propTypes = {};

function Sale() {
  return <div>Sale</div>;
}

export default Sale;
