import React from 'react';
//import PropTypes from 'prop-types';
import './_heading.scss'

const Heading = () => {
    return (
        <div className="product-heading">
            <div></div>
            <div className="showing">Showing 01-09 of 17 Results</div>
        </div>
    );
};


// Heading.propTypes = {

// };


export default Heading;
