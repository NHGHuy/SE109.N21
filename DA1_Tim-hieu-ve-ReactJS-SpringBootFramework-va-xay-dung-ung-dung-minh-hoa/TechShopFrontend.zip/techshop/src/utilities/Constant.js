export const CART_EXPIRE_HOURS = 2;
export const WISH_LIST_EXPIRE_HOURS = 2;
export const REVIEWS_PER_PAGE = 4;
export const DEFAULT_REVIEW_PAGE = 0;
