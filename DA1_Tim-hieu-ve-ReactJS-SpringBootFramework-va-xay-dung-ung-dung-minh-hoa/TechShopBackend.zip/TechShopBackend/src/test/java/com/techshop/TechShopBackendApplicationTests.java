package com.techshop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TechShopBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
