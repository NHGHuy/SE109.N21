package com.techshopbe.service;

import java.util.List;

import com.techshopbe.entity.Category;

public interface CategoryService {
	public List<Category> getAll();
}
