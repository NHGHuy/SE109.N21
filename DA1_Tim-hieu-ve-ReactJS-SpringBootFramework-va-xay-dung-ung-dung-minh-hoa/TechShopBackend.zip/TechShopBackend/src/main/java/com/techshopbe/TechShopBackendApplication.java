package com.techshopbe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TechShopBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(TechShopBackendApplication.class, args);
	}

}
